# plant-disease-resnet50-cnn
In this project, I have developed a ResNet50 model from scratch and applied it to classify 10 different classes of plant diseases. The goal of the project is to leverage the powerful ResNet50 architecture to accurately identify and classify various diseases that affect tomato plants, contributing to better disease management and crop yield.
